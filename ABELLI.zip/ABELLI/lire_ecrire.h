SLIDER init_slider(char *nom,SLIDER S);
void ecrire_dans_fic(char*fic,int L,int H);
