PILE push(PILE l, SLIDER S);
PILE recommencer(PILE l);
void libere_murs(SLIDER S);
PILE retour(PILE l,SLIDER S,int c);
PILE touche(PILE l,SLIDER S,int c);
PILE jeu(SLIDER S,PILE mouv);
