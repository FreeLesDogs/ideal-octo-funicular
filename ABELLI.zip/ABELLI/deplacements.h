SLIDER deplace_droite(SLIDER S);
SLIDER deplace_gauche(SLIDER S);
SLIDER deplace_haut(SLIDER S);
SLIDER deplace_bas(SLIDER S);
